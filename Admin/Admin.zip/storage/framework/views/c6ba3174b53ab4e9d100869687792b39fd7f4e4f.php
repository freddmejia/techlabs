<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card card-default">
                <div class="card-header">REPORTE GENERAL</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="GET" action="/home">
                        <?php echo csrf_field(); ?>
                        DESDE : <input name="desde" type="date" />
                        HASTA : <input name="hasta" type="date"/>
                        <button type="submit" class="btn btn-primary">BUSCAR</button>
                    </form>

                <table class="table">
                <thead class="thead-dark">
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Jugador</th>
                    <th scope="col">Genero</th>
                    <th scope="col">Copas</th>
                    <th scope="col">Estrellas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $jugadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jugador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($i++); ?></th>
                        <th><?php echo e($jugador->nickname); ?></th>
                        <th><?php echo e($jugador->genero); ?></th>
                        <th><?php echo e($jugador->copas); ?></th>
                        <th><?php echo e($jugador->estrellas); ?></th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>